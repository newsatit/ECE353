
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'nRF24L01p_Demo' 
 * Target:  'nRF24L01p_Demo' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "TM4C123.h"


#endif /* RTE_COMPONENTS_H */
